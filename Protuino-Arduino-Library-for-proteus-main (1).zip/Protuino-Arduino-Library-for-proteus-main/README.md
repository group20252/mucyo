# Protuino-Arduino-Library-for-proteus

This Protuino uno library is modified version of simulino library with some new graphics and with stable release for almost all proteus version support.

## Boards Available (More boards are comming soon) :

:heavy_check_mark:Arduino Uno
- [ ] Arduino Nano
- [ ] Arduino Mega
- [ ] Aduino Pro Mini

### How to add in proteus :

* Download or Clone Protuino Library for proteus repository and copy PROTUINO.IDX and PROTUINO.LIB file.
* Now open your proteus installation directorty, then find library folder and paste both files there.
* Restart your Proteus Professional and open library manager.
* Search "Protuino" and you will find protuino library inside library manager, select it and place it in schematic workplace and start simulation.
